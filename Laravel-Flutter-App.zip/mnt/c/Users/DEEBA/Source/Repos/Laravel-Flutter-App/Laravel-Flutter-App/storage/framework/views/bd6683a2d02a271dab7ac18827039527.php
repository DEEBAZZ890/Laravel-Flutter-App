<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Add Answer')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <h3 class="font-bold text-gray-700 text-lg mb-4">
                        <?php echo e(__("Create New Answer")); ?>

                    </h3>

                    <?php if($errors->any()): ?>
                        <div class="bg-red-200 text-red-800 p-2 rounded border-red-800 mb-4">
                            <i class="fa fa-triangle-exclamation text-xl pl-2 pr-4"></i>
                            You have errors in your form submission.
                        </div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('answers.store')); ?>" method="post" class="flex flex-col gap-4">
                        <?php echo csrf_field(); ?>

                        <!-- Question Select Dropdown -->
                        <div class="grid grid-cols-6 gap-1">
                            <label for="question_id" class=""><?php echo e(__("Question")); ?></label>
                            <select id="question_id" name="question_id" class="p-2 col-span-5">
                                <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($question->id); ?>"><?php echo e($question->content); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['question_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-800 mb-2 text-sm col-span-5"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Answer Content -->
                        <div class="grid grid-cols-6 gap-1">
                            <label for="content" class=""><?php echo e(__("Content")); ?></label>
                            <input id="content" name="content" type="text" class="p-2 col-span-5" value="<?php echo e(old('content')); ?>">
                            <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-800 mb-2 text-sm col-span-5"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Is Correct Checkbox -->
                        <div class="grid grid-cols-6 gap-1">
                            <label for="is_correct" class=""><?php echo e(__("Correct Answer?")); ?></label>
                            <input id="is_correct" name="is_correct" type="checkbox" class="p-2 col-span-5">
                            <?php $__errorArgs = ['is_correct'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-800 mb-2 text-sm col-span-5"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Form Buttons -->
                        <div class="grid grid-cols-6 gap-4">
                            <span></span>
                            <div class="mt-6 col-span-5 flex flex-row gap-4 -ml-2">
                                <a href="<?php echo e(route('answers.index')); ?>"
                                   class="py-2 px-4 mx-2 w-1/6 text-center rounded border border-stone-600 hover:bg-stone-600 text-stone-600 hover:text-white transition duration-500">
                                    <i class="fa fa-circle-left"></i> <?php echo e(__("Back")); ?>

                                </a>
                                <button type="submit"
                                        class="py-2 px-4 mx-2 w-1/6 text-center rounded border border-red-600 hover:bg-red-600 text-red-600 hover:text-white transition duration-500">
                                    <i class="fa fa-save"></i> <?php echo e(__("Save")); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/answers/create.blade.php ENDPATH**/ ?>
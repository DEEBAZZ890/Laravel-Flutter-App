<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Add Result')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <h3 class="font-bold text-gray-700 text-lg mb-4">
                        <?php echo e(__("Add New Result")); ?>

                    </h3>

                    <?php if($errors->any()): ?>
                        <div class="bg-red-200 text-red-800 p-2 rounded border-red-800 mb-4">
                            <i class="fa fa-exclamation-triangle text-xl pl-2 pr-4"></i>
                            You have errors in your form submission.
                        </div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('results.store')); ?>" method="post" class="flex flex-col gap-4">
                        <?php echo csrf_field(); ?>

                        <!-- Quiz Attempt ID Field -->
                        <div class="grid grid-cols-6 gap-1">
                            <label for="quiz_attempt_id" class=""><?php echo e(__("Quiz Attempt ID")); ?></label>
                            <input id="quiz_attempt_id" name="quiz_attempt_id" type="number"
                                   class="p-2 col-span-5"
                                   value="<?php echo e(old('quiz_attempt_id')); ?>">
                            <?php $__errorArgs = ['quiz_attempt_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-800 mb-2 text-sm col-span-5"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- User ID Field -->
                        <div class="grid grid-cols-6 gap-1">
                            <label for="user_id" class=""><?php echo e(__("User ID")); ?></label>
                            <input id="user_id" name="user_id" type="number"
                                   class="p-2 col-span-5"
                                   value="<?php echo e(old('user_id')); ?>">
                            <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-800 mb-2 text-sm col-span-5"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Score Field -->
                        <div class="grid grid-cols-6 gap-1">
                            <label for="score" class=""><?php echo e(__("Score")); ?></label>
                            <input id="score" name="score" type="number"
                                   class="p-2 col-span-5"
                                   value="<?php echo e(old('score')); ?>">
                            <?php $__errorArgs = ['score'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-800 mb-2 text-sm col-span-5"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Passed Field -->
                        <div class="grid grid-cols-6 gap-1">
                            <label for="passed" class=""><?php echo e(__("Passed")); ?></label>
                            <select id="passed" name="passed" class="p-2 col-span-5">
                                <option value="1" <?php echo e(old('passed') == '1' ? 'selected' : ''); ?>>Yes</option>
                                <option value="0" <?php echo e(old('passed') == '0' ? 'selected' : ''); ?>>No</option>
                            </select>
                            <?php $__errorArgs = ['passed'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-800 mb-2 text-sm col-span-5"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Feedback Field -->
                        <div class="grid grid-cols-6 gap-1">
                            <label for="feedback" class=""><?php echo e(__("Feedback")); ?></label>
                            <textarea id="feedback" name="feedback"
                                      class="p-2 col-span-5"><?php echo e(old('feedback')); ?></textarea>
                            <?php $__errorArgs = ['feedback'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-red-800 mb-2 text-sm col-span-5"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="grid grid-cols-6 gap-4">
                            <span></span>
                            <div class="mt-6 col-span-5 flex flex-row gap-4 -ml-2">
                                <a href="<?php echo e(route('results.index')); ?>"
                                   class="py-2 px-4 mx-2 w-1/6 text-center
                                      rounded border border-stone-600
                                      hover:bg-stone-600
                                      text-stone-600 hover:text-white
                                      transition duration-500">
                                    <i class="fa fa-circle-left"></i> <?php echo e(__("Back")); ?>

                                </a>

                                <button type="submit"
                                        class="py-2 px-4 mx-2 w-1/6 text-center
                                       rounded border border-red-600
                                       hover:bg-red-600
                                       text-red-600 hover:text-white
                                       transition duration-500">
                                    <i class="fa fa-save"></i> <?php echo e(__("Save")); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/results/create.blade.php ENDPATH**/ ?>
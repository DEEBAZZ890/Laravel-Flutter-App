<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Answers')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(route('answers.create')); ?>"
                           class="rounded mb-6 p-2 bg-sky-500 text-white text-center w-1/5 min-w-64">
                            <?php echo e(__('Add new Answer')); ?>

                        </a>
                    <?php endif; ?>

                    <?php if($answers->isEmpty()): ?>
                        <p><?php echo e(__('No answers found.')); ?></p>
                    <?php else: ?>
                        <table class="table w-full">
                            <caption><?php echo e(__('All Answers (paginated)')); ?></caption>
                            <thead class="border border-stone-300">
                            <tr class="bg-stone-300">
                                <th class="p-2 text-right">#</th>
                                <th class="p-2 text-left"><?php echo e(__("Content")); ?></th>
                                <th class="p-2 text-left"><?php echo e(__("Question")); ?></th>
                                <th class="p-2 text-left"><?php echo e(__("Correct")); ?></th>
                                <th class="p-2 text-left"><?php echo e(__("Actions")); ?></th>
                            </tr>
                            </thead>
                            <tbody class="border border-stone-300">
                            <?php $__currentLoopData = $answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="border-b border-stone-300 hover:bg-stone-200 transition duration-500 ease-in-out">
                                    <td class="p-2 text-right"><?php echo e($loop->iteration); ?></td>
                                    <td class="p-2"><?php echo e($answer->content); ?></td>
                                    <td class="p-2"><?php echo e($answer->question->content); ?></td>
                                    <td class="p-2"><?php echo e($answer->is_correct ? 'Yes' : 'No'); ?></td>
                                    <td class="py-2 pl-2 pr-0 flex flex-row gap-2">
                                        <a href="<?php echo e(route('answers.show', $answer)); ?>"
                                           class="px-2 w-12 text-center rounded-md border border-emerald-600
                                          hover:bg-emerald-600 hover:text-white transition duration-500">
                                            <span class="sr-only">View</span>
                                            <i class="fa fa-eye"></i>
                                        </a>
                                        <a href="<?php echo e(route('answers.edit', $answer)); ?>"
                                           class="px-2 w-12 text-center rounded-md border border-sky-600
                                          hover:bg-sky-600 hover:text-white transition duration-500">
                                            <span class="sr-only">Edit</span>
                                            <i class="fa fa-pen"></i>
                                        </a>
                                        <a href="<?php echo e(route('answers.delete', $answer)); ?>"
                                           class="px-2 w-12 text-center rounded-md border border-red-600
                                          hover:bg-red-600 hover:text-white transition duration-500">
                                            <span class="sr-only">Delete</span>
                                            <i class="fa fa-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot class="border border-stone-300">
                            <tr>
                                <td colspan="5" class="p-2">
                                    <?php echo e($answers->links()); ?>

                                </td>
                            </tr>
                            </tfoot>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/answers/index.blade.php ENDPATH**/ ?>
<small class="badge badge-<?php echo e($colour); ?>"><?php echo e($text); ?></small>
<?php /**PATH /var/www/html/resources/views/vendor/scribe/components/badges/base.blade.php ENDPATH**/ ?>
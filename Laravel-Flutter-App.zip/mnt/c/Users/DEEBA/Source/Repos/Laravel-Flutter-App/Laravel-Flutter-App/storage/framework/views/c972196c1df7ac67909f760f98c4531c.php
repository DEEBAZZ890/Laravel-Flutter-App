<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Add New Question')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                    <form action="<?php echo e(route('questions.store')); ?>"
                          method="POST"
                          class="flex flex-col gap-4">
                        <?php echo csrf_field(); ?>

                        <div class="grid grid-cols-6 gap-4">
                            <label for="quiz_id" class="col-span-1"><?php echo e(__("Quiz")); ?></label>
                            <select id="quiz_id" name="quiz_id" class="p-2 col-span-5">
                                <?php $__currentLoopData = $quizzes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($quiz->id); ?>"><?php echo e($quiz->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="grid grid-cols-6 gap-4">
                            <label for="content" class="col-span-1"><?php echo e(__("Content")); ?></label>
                            <textarea id="content" name="content" class="p-2 col-span-5"></textarea>
                        </div>

                        <div class="grid grid-cols-6 gap-4">
                            <label for="type" class="col-span-1"><?php echo e(__("Type")); ?></label>
                            <input type="text" id="type" name="type" class="p-2 col-span-5">
                        </div>

                        <div class="grid grid-cols-6 gap-4">
                            <label for="points" class="col-span-1"><?php echo e(__("Points")); ?></label>
                            <input type="number" id="points" name="points" class="p-2 col-span-5">
                        </div>

                        <div class="flex justify-end mt-4">
                            <a href="<?php echo e(route('questions.index')); ?>"
                               class="mx-2 btn btn-secondary">
                                <?php echo e(__("Cancel")); ?>

                            </a>
                            <button type="submit" class="mx-2 btn btn-primary">
                                <?php echo e(__("Save")); ?>

                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/questions/create.blade.php ENDPATH**/ ?>
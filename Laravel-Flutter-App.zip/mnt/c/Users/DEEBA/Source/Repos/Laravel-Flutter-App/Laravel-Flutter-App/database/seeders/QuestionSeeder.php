<?php

namespace Database\Seeders;

use App\Models\Question;
use App\Models\Quiz;
use Illuminate\Database\Seeder;

class QuestionSeeder extends Seeder
{
    public function run()
    {
        // Define question types for variety
        $questionTypes = ['multiple_choice', 'true_false', 'short_answer'];

        // Retrieve all quizzes
        $quizzes = Quiz::all();

        foreach ($quizzes as $quiz) {
            for ($i = 1; $i <= 20; $i++) { // 20 questions per quiz
                Question::create([
                    'quiz_id' => $quiz->id,
                    'content' => "Dummy question content $i for quiz " . $quiz->id,
                    'type' => $questionTypes[array_rand($questionTypes)], // Randomly select a question type
                    'points' => 1 // Each question is worth 1 point
                ]);
            }
        }
    }
}

